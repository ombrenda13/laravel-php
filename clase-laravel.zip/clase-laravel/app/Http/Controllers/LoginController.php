<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\LoginCustomRequest;



class LoginController extends Controller
{
    public function login(Request $request)
    {
      //dd($request);
      return view('login');
    }
    public function LoginSave(LoginCustomRequest $request)
    {

        dd($request->all());

    }
}
