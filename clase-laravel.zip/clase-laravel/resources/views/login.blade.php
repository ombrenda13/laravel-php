

<h1>Create Post</h1>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{route('LoginSaveRoute')}}" method="post">
   {{ csrf_field() }}
  <h1>Create a new account</h1>
  <h2>it's free</h2>
  <div>
    <section>
      <label>First Name </label>
      <input type="text" name="firstName">
      <label>Last Name</label>

      <input type="text" name="lastName" id="" class="">
    </section>
    <label>Email </label>

    <input type="email" name="email" id="">
    <label>Password </label>

    <input type="password" name="password">
  </div>

  <button type="submit">Create account</button>

</form>
