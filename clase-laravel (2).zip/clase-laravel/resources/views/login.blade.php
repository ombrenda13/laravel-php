
<h1>Create Post</h1>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{route('login')}}" method="post">
   {{ csrf_field() }}
  <h1>Create a new account</h1>
  <h2>it's free</h2>
  <div>
    <section>
      <label>First Name </label>
      <input type="text" name="fisrtName" value="{{old('fisrtName')}}">
      <label>Last Name</label>

      <input type="text" name="lastName" id="" class="" value="{{old('lastName')}}">
    </section>
    <label>Email </label>

    <input type="text" name="email" id="" value="{{old('email')}}">
    <label>Password </label>

    <input type="password" name="password">
  </div>

  <button type="submit">Create account</button>

</form>
<a/ href="{{route('accounts')}}">
   Show accounts
</a>
