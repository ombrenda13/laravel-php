@extends('main')
@section('content')

<form action="{{route('login')}}" method="post">
   {{ csrf_field() }}
  <h1>Edit  account</h1>
  <div class="form-group">
   <label >FIRST NAME</label>
   <input type="text" name= fisrtName value="{{old('fisrtName',$q->fisrtName)}}">
 </div>
  <div class="form-group">
     <label for="exampleInputEmail1">Email address</label>
     <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
     <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
   </div>
  <div>
    <section>
      <label>First Name </label>
      <input type="text" name="fisrtName" value="{{old('fisrtName')}}">
      <label>Last Name</label>

      <input type="text" name="lastName" id="" class="" value="{{old('lastName')}}">
    </section>
    <label>Email </label>

    <input type="text" name="email" id="" value="{{old('email')}}">
    <label>Password </label>

    <input type="password" name="password">
  </div>

  <button type="submit">Create account</button>

</form>
<a/ href="{{route('accounts')}}">
   Show accounts
</a>

@endsection
