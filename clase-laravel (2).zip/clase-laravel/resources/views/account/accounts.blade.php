@extends('main')
@section('content')
<a href="{{route('login')}}">
  createAccount
</a>
<div class"row block-center">
  {{ $q->links() }}

</div>

<table class="table table-striped table-dark">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Firstname</th>
      <th scope="col">Lastname</th>
      <th scope="col">email</th>
      <th scope="col">creted at </th>
      <th scope="col">updated at</th>

    </tr>
  </thead>
  <tbody>
      @foreach($q as $account)
    <tr>
        <td> <a href="{{route('accountEdit',$account->id)}}" class="btn">Edit</a>
        <td>{{$account->id}}</td>
        <td>{{$account->fisrtName}}</td>
        <td>{{$account->lastName}}</td>
        <td>{{$account->email}}</td>
        <td>{{$account->created_at}}</td>
        <td>{{$account->updated_at}}</td>

    </tr>
      @endforeach
  </tbody>
</table>
@endsection
