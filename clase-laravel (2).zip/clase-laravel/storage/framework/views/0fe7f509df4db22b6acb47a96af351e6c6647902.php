<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('login')); ?>" method="post">
   <?php echo e(csrf_field()); ?>

  <h1>Edit  account</h1>
  <div class="form-group">
   <label >FIRST NAME</label>
   <input type="text" name= fisrtName value="<?php echo e(old('fisrtName',$q->fisrtName)); ?>">
 </div>
  
  <div>
    <section>
      <label>First Name </label>
      <input type="text" name="fisrtName" value="<?php echo e(old('fisrtName')); ?>">
      <label>Last Name</label>

      <input type="text" name="lastName" id="" class="" value="<?php echo e(old('lastName')); ?>">
    </section>
    <label>Email </label>

    <input type="text" name="email" id="" value="<?php echo e(old('email')); ?>">
    <label>Password </label>

    <input type="password" name="password">
  </div>

  <button type="submit">Create account</button>

</form>
<a/ href="<?php echo e(route('accounts')); ?>">
   Show accounts
</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>