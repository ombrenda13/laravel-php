<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('login')); ?>">
  createAccount
</a>
<div class"row block-center">
  <?php echo e($q->links()); ?>


</div>

<table class="table table-striped table-dark">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Firstname</th>
      <th scope="col">Lastname</th>
      <th scope="col">email</th>
      <th scope="col">creted at </th>
      <th scope="col">updated at</th>

    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $q; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <a href="<?php echo e(route('accountEdit',$account->id)); ?>" class="btn">Edit</a>
        <td><?php echo e($account->id); ?></td>
        <td><?php echo e($account->fisrtName); ?></td>
        <td><?php echo e($account->lastName); ?></td>
        <td><?php echo e($account->email); ?></td>
        <td><?php echo e($account->created_at); ?></td>
        <td><?php echo e($account->updated_at); ?></td>

    </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
