
<h1>Create Post</h1>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('login')); ?>" method="post">
   <?php echo e(csrf_field()); ?>

  <h1>Create a new account</h1>
  <h2>it's free</h2>
  <div>
    <section>
      <label>First Name </label>
      <input type="text" name="fisrtName" value="<?php echo e(old('fisrtName')); ?>">
      <label>Last Name</label>

      <input type="text" name="lastName" id="" class="" value="<?php echo e(old('lastName')); ?>">
    </section>
    <label>Email </label>

    <input type="text" name="email" id="" value="<?php echo e(old('email')); ?>">
    <label>Password </label>

    <input type="password" name="password">
  </div>

  <button type="submit">Create account</button>

</form>
<a/ href="<?php echo e(route('accounts')); ?>">
   Show accounts
</a>
