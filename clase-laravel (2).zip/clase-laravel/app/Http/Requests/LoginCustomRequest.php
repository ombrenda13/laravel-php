<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LoginCustomRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**s
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
    //  dd(1);
    if ($this->isMethod('GET')){

      return[]; //el get no realiza ninguna validacion porque solamente recupera de la vista

    }
        return [
          'fisrtName'=>'required',
          'lastName'=>'required',
          'email'=>'required|email|unique:accounts',
          'password'=>'required|min:8|max:10'
            //
        ];
    }
    public function messages()
    {
      return[  'fisrtName.required'=>'the fisrt name is required',
        'lastName.required'=>'the last name is required ',
        'email.required'=>'the email is required',
        'email.unique'=>'the email is not unique',
        'email.email'=>'the email format is invalid',
        'password.required'=>'the password is required ',
        'password.min'=> 'the password needs a minimum of 8 chars',
        'password.max'=> 'the password needs a max of 10 chars'

      ];
    }
}
