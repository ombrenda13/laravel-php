<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\LoginCustomRequest;
use DB;
use App\Account;


class LoginController extends Controller
{
    public function Login(LoginCustomRequest $request)
    {
      //dd($request);
      if($request->isMethod('GET')){
        return view('login');
      }

    //    dd($request->all());
        //after validation.. save to data base
        Account::create($request->all());//data base model created in console
        return redirect()->back();
      } //regresar al formulario después de registrarse
        public function accounts(Request $request)
        {
          $q=Account::paginate(5);
        //  dd($q);
          return view('account.accounts',['q'=> $q]);
        }

      public function accountEdit(LoginCustomRequest $request,$id)
      {
          $q =Account::findOrFail($id);
          //$q = Account::where('id',$id)->first();
          return view('account.account-edit',['q'=>$q]);
      }

}
